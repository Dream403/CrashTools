//
//  AppDelegate.h
//  CrasgToolDemo
//
//  Created by Snow_lu on 2017/3/8.
//  Copyright © 2017年 小虾米. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

